using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
[assembly: AssemblyTitle("SmartRedundancy")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Blue Cell Software LLC")]
[assembly: AssemblyProduct("SmartRedundancy")]
[assembly: AssemblyCopyright("Copyright © Blue Cell Software LLC 2011")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("2cffc027-5cf6-49e5-8bb2-7e1b45140475")]
[assembly: AssemblyVersion("0.0.0.0")]
[assembly: AssemblyFileVersion("0.0.0.0")]

